document.addEventListener('DOMContentLoaded', () => {
    const loginContainer = document.getElementById('login-container');
    const openLoginBtn = document.getElementById('open-login');
    const openRegisterBtn = document.getElementById('open-register');
    const openLoginMobile = document.getElementById('open-login-mobile');
    const openRegisterMobile = document.getElementById('open-register-mobile');

    const showLoginForm = () => {
        loginContainer.classList.remove('move');
    };

    const showRegisterForm = () => {
        loginContainer.classList.add('move');
    };

    if (openLoginBtn) openLoginBtn.addEventListener('click', showLoginForm);
    if (openRegisterBtn) openRegisterBtn.addEventListener('click', showRegisterForm);
    if (openLoginMobile) openLoginMobile.addEventListener('click', (e) => {
        e.preventDefault();
        showLoginForm();
    });
    if (openRegisterMobile) openRegisterMobile.addEventListener('click', (e) => {
        e.preventDefault();
        showRegisterForm();
    });

    const currentMode = localStorage.getItem('loginMode');
    if (currentMode === 'register') {
        showRegisterForm();
    } else {
        showLoginForm();
    }

    const updateModeStorage = () => {
        if (loginContainer.classList.contains('register-mode')) {
            localStorage.setItem('loginMode', 'register');
        } else {
            localStorage.setItem('loginMode', 'login');
        }
    };

    loginContainer.addEventListener('transitionend', updateModeStorage);

    const registerForm = document.querySelector('.form-register');

    if (registerForm) {
        registerForm.addEventListener('submit', function (e) {
            e.preventDefault();

            const formData = new FormData(registerForm);
            const usuario = {
                nome: formData.get('nome'),
                idade: parseInt(formData.get('idade')),
                email: formData.get('email'),
                senha: formData.get('senha')
            };

            fetch('/usuarios', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(usuario)
            })
                .then(response => {
                    if (response.ok) {
                        alert('Cadastro realizado com sucesso!');
                        window.location.href = '/login';
                    } else {
                        return response.json().then(data => {
                            throw new Error(data.message || 'Erro ao cadastrar usuário.');
                        });
                    }
                })
                .catch(error => {
                    alert('Erro: ' + error.message);
                });
        });
    }

});
