document.addEventListener('DOMContentLoaded', function() {
    const logoImage = document.getElementById('logo-image');
    const startButtonContainer = document.querySelector('.start-button-container');
    const startButton = document.getElementById('start-button');

    if (logoImage) {
        logoImage.addEventListener('animationend', () => {
            if (startButtonContainer) {
                startButtonContainer.classList.add('start-button-visible');
            } else {
                console.error('Elemento com classe "start-button-container" não encontrado.');
            }
        });
    } else {
        console.error('Elemento com ID "logo-image" não encontrado.');
    }

    if (startButton) {
        startButton.addEventListener('click', function() {
            window.location.href = '/login';
        });
    }

});
