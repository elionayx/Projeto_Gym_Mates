package app.service;

import app.model.Conquista;
import app.model.TipoConquista;
import app.model.Usuario;
import app.repository.ConquistaRepository;
import app.repository.TreinoRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
public class ConquistaService {

    private final ConquistaRepository conquistaRepository;
    private final TreinoRepository treinoRepository;

    public ConquistaService(ConquistaRepository conquistaRepository, TreinoRepository treinoRepository) {
        this.conquistaRepository = conquistaRepository;
        this.treinoRepository = treinoRepository;
    }

    public void verificarConquistas(Usuario usuario) {
        LocalDate hoje = LocalDate.now();
        LocalDate inicioSemana = hoje.minusDays(7);
        LocalDate inicioMes = hoje.withDayOfMonth(1);

        long treinosSemana = treinoRepository.countByUsuarioAndDataBetween(usuario, inicioSemana, hoje);
        long treinosMes = treinoRepository.countByUsuarioAndDataBetween(usuario, inicioMes, hoje);

        if (treinosSemana >= 5 && !conquistaRepository.existsByUsuarioAndTipo(usuario, TipoConquista.TREINOS_5_SEMANA)) {
            conquistaRepository.save(new Conquista(TipoConquista.TREINOS_5_SEMANA, hoje, usuario));
        }

        if (treinosMes >= 10 && !conquistaRepository.existsByUsuarioAndTipo(usuario, TipoConquista.TREINOS_10_MES)) {
            conquistaRepository.save(new Conquista(TipoConquista.TREINOS_10_MES, hoje, usuario));
        }
    }

    public List<Conquista> listarConquistas(Usuario usuario) {
        return conquistaRepository.findByUsuario(usuario);
    }
}
