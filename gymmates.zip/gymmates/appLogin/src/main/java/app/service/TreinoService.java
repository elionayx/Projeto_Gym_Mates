package app.service;

import app.dto.RankingDTO;
import app.model.Grupo;
import app.model.Treino;
import app.model.Usuario;
import app.repository.TreinoRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class TreinoService {

    private final TreinoRepository treinoRepository;
    private final ConquistaService conquistaService;
    private final UsuarioService usuarioService;

    public TreinoService(TreinoRepository treinoRepository, ConquistaService conquistaService, UsuarioService usuarioService) {
        this.treinoRepository = treinoRepository;
        this.conquistaService = conquistaService;
        this.usuarioService = usuarioService;
    }

    public Treino salvarTreino(Treino treino) {
        treino.setPontos(calcularPontos(treino));

        Usuario usuario = treino.getUsuario();
        conquistaService.verificarConquistas(usuario);

        return treinoRepository.save(treino);
    }

    public List<Treino> listarPorUsuario(Usuario usuario) {
        return treinoRepository.findByUsuario(usuario);
    }

    public List<Treino> listarPorGrupo(Grupo grupo) {
        return treinoRepository.findByGrupo(grupo);
    }

    private int calcularPontos(Treino treino) {
        int base = treino.getDuracao();
        return switch (treino.getIntensidade().toLowerCase()) {
            case "alta" -> base * 3;
            case "média" -> base * 2;
            default -> base;
        };
    }

    public List<RankingDTO> obterRankingPorGrupo(Grupo grupo) {
        return treinoRepository.buscarRankingPorGrupo(grupo.getId());
    }

}
