package app.service;

import app.model.Grupo;
import app.model.Usuario;
import app.repository.GrupoRepository;
import app.repository.UsuarioRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class GrupoService {

    private final GrupoRepository grupoRepository;
    private final UsuarioRepository usuarioRepository;

    public GrupoService(GrupoRepository grupoRepository, UsuarioRepository usuarioRepository) {
        this.grupoRepository = grupoRepository;
        this.usuarioRepository = usuarioRepository;
    }

    @Transactional
    public Grupo criarGrupo(Grupo grupo, Long idCriador) {
        Usuario criador = usuarioRepository.findById(idCriador)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

        grupo.setCriador(criador);
        grupo = grupoRepository.save(grupo);
        grupo.getMembros().add(criador);

        return grupoRepository.save(grupo);
    }

    @Transactional
    public void adicionarMembro(Long idGrupo, Long idUsuario) {
        Grupo grupo = grupoRepository.findById(idGrupo)
                .orElseThrow(() -> new RuntimeException("Grupo não encontrado"));
        Usuario usuario = usuarioRepository.findById(idUsuario)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        grupo.getMembros().add(usuario);
        grupoRepository.save(grupo);
    }

    public List<Grupo> listarGruposPorUsuario(Long idUsuario) {
        return grupoRepository.findByMembros_Id(idUsuario);
    }

    public Grupo buscarPorId(Long id) {
        return grupoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Grupo não encontrado"));
    }


    @Transactional
    public void removerMembro(Long idGrupo, Long idUsuario) {
        Grupo grupo = grupoRepository.findById(idGrupo)
                .orElseThrow(() -> new RuntimeException("Grupo não encontrado"));
        Usuario usuario = usuarioRepository.findById(idUsuario)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        grupo.getMembros().remove(usuario);
        grupoRepository.save(grupo);
    }

    public List<Usuario> listarTodosUsuarios() {
        return usuarioRepository.findAll();
    }

}

