package app.service;

import app.dto.RankingDTO;
import app.model.Usuario;
import app.repository.TreinoRepository;
import app.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class RankingService {

    private final TreinoRepository treinoRepository;
    private final UsuarioRepository usuarioRepository;

    public RankingService(TreinoRepository treinoRepository, UsuarioRepository usuarioRepository) {
        this.treinoRepository = treinoRepository;
        this.usuarioRepository = usuarioRepository;
    }

    public List<RankingDTO> gerarRankingSemanal() {
        LocalDate fim = LocalDate.now();
        LocalDate inicio = fim.minusDays(7);
        return gerarRankingEntre(inicio, fim);
    }

    public List<RankingDTO> gerarRankingMensal() {
        LocalDate fim = LocalDate.now();
        LocalDate inicio = fim.withDayOfMonth(1);
        return gerarRankingEntre(inicio, fim);
    }

    private List<RankingDTO> gerarRankingEntre(LocalDate inicio, LocalDate fim) {
        List<Object[]> dados = treinoRepository.calcularRankingEntreDatas(inicio, fim);
        List<Long> ids = dados.stream()
                .map(linha -> (Long) linha[0])
                .collect(Collectors.toList());

        Map<Long, String> nomesPorId = usuarioRepository.findAllById(ids).stream()
                .collect(Collectors.toMap(Usuario::getId, Usuario::getNome));

        List<RankingDTO> ranking = new ArrayList<>();
        for (Object[] linha : dados) {
            Long usuarioId = (Long) linha[0];
            Integer totalPontos = ((Number) linha[1]).intValue();
            String nome = nomesPorId.get(usuarioId);
            if (nome != null) {
                ranking.add(new RankingDTO(nome, (long) totalPontos));
            }
        }

        return ranking;
    }

}

