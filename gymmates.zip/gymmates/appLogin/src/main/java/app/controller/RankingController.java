package app.controller;

import app.service.RankingService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class RankingController {

    private final RankingService rankingService;

    public RankingController(RankingService rankingService) {
        this.rankingService = rankingService;
    }

    @GetMapping("/ranking")
    public String mostrarRanking(Model model) {
        model.addAttribute("semanal", rankingService.gerarRankingSemanal());
        model.addAttribute("mensal", rankingService.gerarRankingMensal());
        return "ranking";
    }
}

