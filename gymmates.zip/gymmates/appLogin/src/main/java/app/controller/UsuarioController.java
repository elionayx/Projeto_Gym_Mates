package app.controller;

import app.model.Usuario;
import app.repository.UsuarioRepository;
import app.service.ConquistaService;
import app.service.UsuarioService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("/usuarios")
public class UsuarioController {
    private final UsuarioService usuarioService;
    private final ConquistaService conquistaService;
    private final UsuarioRepository usuarioRepository;

    public UsuarioController(UsuarioService usuarioService, ConquistaService conquistaService, UsuarioRepository usuarioRepository) {
        this.usuarioService = usuarioService;
        this.conquistaService = conquistaService;
        this.usuarioRepository = usuarioRepository;
    }

    @PostMapping
    public ResponseEntity<Usuario> cadastrar(@RequestBody Usuario usuario){
       return new ResponseEntity<>(this.usuarioService.cadastrarUsuario(usuario), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public String getPerfil(@PathVariable Long id, Model model, HttpSession session) {
        Long usuarioLogadoId = (Long) session.getAttribute("usuarioLogadoId");

        if (usuarioLogadoId == null || !usuarioLogadoId.equals(id)) {
            return "redirect:/login";
        }

        Optional<Usuario> usuario = usuarioService.buscarPorId(id);
        if (usuario.isPresent()) {
            model.addAttribute("usuario", usuario.get());
            return "perfil";  // nome do template perfil.html
        } else {
            return "redirect:/home";
        }
    }

    @GetMapping("/perfil")
    public String mostrarPerfil(HttpSession session, Model model) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        if (usuario == null) {
            return "redirect:/login";
        }

        model.addAttribute("usuario", usuario);
        model.addAttribute("conquistas", conquistaService.listarConquistas(usuario));
        return "perfil";
    }

    @GetMapping("/editar-perfil")
    public String mostrarFormularioEdicao(HttpSession session, Model model) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        if (usuario == null) {
            return "redirect:/login";
        }

        model.addAttribute("usuario", usuario);
        return "editar-perfil";
    }

    @PostMapping("/editar-perfil")
    public String salvarEdicaoPerfil(@ModelAttribute Usuario usuarioEditado, HttpSession session) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");

        if (usuario == null) {
            return "redirect:/login";
        }

        usuario.setNome(usuarioEditado.getNome());
        usuario.setEmail(usuarioEditado.getEmail());
        usuario.setIdade(usuarioEditado.getIdade());

        usuarioRepository.save(usuario);
        session.setAttribute("usuario", usuario);

        return "redirect:/perfil";
    }

}
