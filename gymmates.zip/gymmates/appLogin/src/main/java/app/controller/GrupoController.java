package app.controller;

import app.dto.RankingDTO;
import app.model.Grupo;
import app.model.Treino;
import app.model.Usuario;
import app.service.GrupoService;
import app.service.TreinoService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;


@Controller
@RequestMapping("/grupos")
public class GrupoController {

    private final GrupoService grupoService;
    private final TreinoService treinoService;

    public GrupoController(GrupoService grupoService, TreinoService treinoService) {
        this.grupoService = grupoService;
        this.treinoService = treinoService;
    }

    @GetMapping
    public String listarGrupos(HttpSession session, Model model) {
        Long idUsuario = (Long) session.getAttribute("usuarioLogadoId");
        model.addAttribute("grupos", grupoService.listarGruposPorUsuario(idUsuario));
        return "grupos";
    }

    @PostMapping
    public String criarGrupo(@RequestParam String nome, HttpSession session) {
        Long idCriador = (Long) session.getAttribute("usuarioLogadoId");
        Grupo grupo = new Grupo();
        grupo.setNome(nome);
        grupoService.criarGrupo(grupo, idCriador);
        return "redirect:/grupos";
    }


    @PostMapping("/{idGrupo}/membros")
    public String adicionarMembro(
            @PathVariable Long idGrupo,
            @RequestParam Long idUsuario) {
        grupoService.adicionarMembro(idGrupo, idUsuario);
        return "redirect:/grupos/" + idGrupo;
    }

    @GetMapping("/{id}")
    public String detalhesGrupo(@PathVariable Long id, Model model) {
        Grupo grupo = grupoService.buscarPorId(id);

        // Crie uma cópia da lista para evitar ConcurrentModificationException
        List<Usuario> membros = new ArrayList<>(grupo.getMembros());
        List<Usuario> todosUsuarios = grupoService.listarTodosUsuarios();

        model.addAttribute("grupo", grupo);
        model.addAttribute("membros", membros);
        model.addAttribute("todosUsuarios", todosUsuarios);

        return "detalhes-grupo";
    }


    @PostMapping("/{idGrupo}/remover-membro")
    public String removerMembro(
            @PathVariable Long idGrupo,
            @RequestParam Long idUsuario) {
        grupoService.removerMembro(idGrupo, idUsuario);
        return "redirect:/grupos/" + idGrupo;
    }

    @GetMapping("/{id}/treinos")
    public String listarTreinosDoGrupo(@PathVariable Long id, Model model) {
        Grupo grupo = grupoService.buscarPorId(id);
        List<Treino> treinos = treinoService.listarPorGrupo(grupo);

        int totalPontos = treinos.stream()
                .filter(t -> t.getPontos() != null)
                .mapToInt(Treino::getPontos)
                .sum();

        model.addAttribute("grupo", grupo);
        model.addAttribute("treinos", treinos);
        model.addAttribute("totalPontos", totalPontos);

        model.addAttribute("novoTreino", new Treino());

        List<String> datasFormatadas = treinos.stream()
                .map(t -> t.getData().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")))
                .toList();
        model.addAttribute("datasFormatadas", datasFormatadas);

        return "treinos-grupo";
    }

    @GetMapping("/{id}/ranking")
    public String exibirRankingDoGrupo(@PathVariable Long id, Model model) {
        Grupo grupo = grupoService.buscarPorId(id);
        List<RankingDTO> ranking = treinoService.obterRankingPorGrupo(grupo);
        model.addAttribute("grupo", grupo);
        model.addAttribute("ranking", ranking);
        return "ranking-grupo";
    }
}


