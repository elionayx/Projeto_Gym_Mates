package app.controller;

import app.model.Usuario;
import app.service.UsuarioService;
import app.service.ConquistaService;
import app.repository.UsuarioRepository;
import jakarta.servlet.http.HttpSession;
import lombok.Data;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import java.util.Optional;

@Data
@Controller
public class PerfilController {

    private final UsuarioService usuarioService;
    private final UsuarioRepository usuarioRepository;
    private final ConquistaService conquistaService;

    public PerfilController(UsuarioService usuarioService, UsuarioRepository usuarioRepository, ConquistaService conquistaService) {
        this.usuarioService = usuarioService;
        this.usuarioRepository = usuarioRepository;
        this.conquistaService = conquistaService;
    }

    @GetMapping("/perfil/editar")
    public String mostrarFormularioEdicaoPerfil(HttpSession session, Model model) {
        Long usuarioLogadoId = (Long) session.getAttribute("usuarioLogadoId");
        if (usuarioLogadoId == null) {
            return "redirect:/login";
        }

        Optional<Usuario> usuarioOpt = usuarioService.buscarPorId(usuarioLogadoId);
        if (usuarioOpt.isPresent()) {
            model.addAttribute("usuario", usuarioOpt.get());
            return "editar-perfil";  // nome da view Thymeleaf
        } else {
            return "redirect:/login";
        }
    }

    @PostMapping("/perfil/editar")
    public String processarEdicaoPerfil(@Validated @ModelAttribute("usuario") Usuario usuario, BindingResult result, HttpSession session, Model model) {
        Long usuarioLogadoId = (Long) session.getAttribute("usuarioLogadoId");
        if (usuarioLogadoId == null) {
            return "redirect:/login";
        }

        if (result.hasErrors()) {
            return "editar-perfil";
        }

        Optional<Usuario> usuarioExistenteOpt = usuarioService.buscarPorId(usuarioLogadoId);
        if (usuarioExistenteOpt.isEmpty()) {
            return "redirect:/login";
        }

        Usuario usuarioExistente = usuarioExistenteOpt.get();

        usuarioExistente.setNome(usuario.getNome());
        usuarioExistente.setEmail(usuario.getEmail());
        usuarioExistente.setIdade(usuario.getIdade());

        usuarioService.cadastrarUsuario(usuarioExistente);

        model.addAttribute("mensagem", "Perfil atualizado com sucesso!");
        return "editar-perfil";
    }


    @GetMapping("/perfil")
    public String mostrarPerfil(HttpSession session, Model model) {
        Long usuarioLogadoId = (Long) session.getAttribute("usuarioLogadoId");

        if (usuarioLogadoId != null) {
            Optional<Usuario> usuario = usuarioService.buscarPorId(usuarioLogadoId);

            if (usuario.isPresent()) {
                model.addAttribute("usuario", usuario.get());
                return "perfil"; // o nome do arquivo HTML
            } else {
                return "redirect:/login";
            }
        } else {
            return "redirect:/login";
        }
    }
}

