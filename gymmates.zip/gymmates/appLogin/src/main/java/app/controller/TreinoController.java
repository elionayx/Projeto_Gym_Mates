package app.controller;

import app.model.Grupo;
import app.model.Treino;
import app.model.Usuario;
import app.service.GrupoService;
import app.service.TreinoService;
import app.service.UsuarioService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/treinos")
public class TreinoController {

    private final TreinoService treinoService;
    private final UsuarioService usuarioService;
    private final GrupoService grupoService;

    public TreinoController(TreinoService treinoService, UsuarioService usuarioService, GrupoService grupoService) {
        this.treinoService = treinoService;
        this.usuarioService = usuarioService;
        this.grupoService = grupoService;
    }

    @GetMapping
    public String mostrarPaginaTreinos(HttpSession session, Model model) {
        Long usuarioId = (Long) session.getAttribute("usuarioLogadoId");
        Optional<Usuario> usuarioOpt = usuarioService.buscarPorId(usuarioId);
        if (usuarioOpt.isEmpty()) {
            return "redirect:/login";
        }

        List<Treino> treinos = treinoService.listarPorUsuario(usuarioOpt.get());

        List<String> datasFormatadas = treinos.stream()
                .map(t -> t.getData().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy")))
                .toList();

        model.addAttribute("treinos", treinos);
        model.addAttribute("datasFormatadas", datasFormatadas);
        model.addAttribute("novoTreino", new Treino());

        List<Grupo> gruposDoUsuario = grupoService.listarGruposPorUsuario(usuarioId);
        if (!gruposDoUsuario.isEmpty()) {
            model.addAttribute("grupo", gruposDoUsuario.get(0)); // ou deixe como lista se quiser mostrar vários
        }

        return "treinos";
    }

    @PostMapping
    public String registrarTreino(@ModelAttribute("novoTreino") Treino treino,
                                  HttpSession session,
                                  @RequestParam(required = false) Long grupoId) {

        Long usuarioId = (Long) session.getAttribute("usuarioLogadoId");
        Optional<Usuario> usuarioOpt = usuarioService.buscarPorId(usuarioId);

        if (usuarioOpt.isEmpty()) {
            return "redirect:/login";
        }

        treino.setUsuario(usuarioOpt.get());
        treino.setData(LocalDate.now());

        if (grupoId != null) {
            Grupo grupo = grupoService.buscarPorId(grupoId);
            if (grupo != null) {
                treino.setGrupo(grupo);
            }
        }

        treinoService.salvarTreino(treino);

        if (grupoId != null) {
            return "redirect:/grupos/" + grupoId + "/treinos";
        }
        return "redirect:/treinos";
    }
}


