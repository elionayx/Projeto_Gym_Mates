package app.repository;

import app.dto.RankingDTO;
import app.model.Grupo;
import app.model.Treino;
import app.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDate;
import java.util.List;

public interface TreinoRepository extends JpaRepository<Treino, Long> {
    List<Treino> findByUsuario(Usuario usuario);

    @Query("SELECT new app.dto.RankingDTO(u.nome, SUM(t.pontos)) " +
            "FROM Treino t JOIN t.usuario u " +
            "WHERE t.grupo.id = :grupoId " +
            "GROUP BY u.id, u.nome " +
            "ORDER BY SUM(t.pontos) DESC")
    List<RankingDTO> buscarRankingPorGrupo(@Param("grupoId") Long grupoId);

    List<Treino> findByGrupo(Grupo grupo);

    List<Treino> findByGrupoIdOrderByDataDesc(Long grupoId);

    long countByUsuarioAndDataBetween(Usuario usuario, LocalDate inicioSemana, LocalDate hoje);

    @Query("SELECT t.usuario.id, SUM(t.pontos) FROM Treino t WHERE t.data BETWEEN :startDate AND :endDate GROUP BY t.usuario.id ORDER BY SUM(t.pontos) DESC")
    List<Object[]> calcularRankingEntreDatas(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
}


