package app.repository;

import app.model.Conquista;
import app.model.Usuario;
import app.model.TipoConquista;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ConquistaRepository extends JpaRepository<Conquista, Long> {
    boolean existsByUsuarioAndTipo(Usuario usuario, TipoConquista tipo);
    List<Conquista> findByUsuario(Usuario usuario);
}

