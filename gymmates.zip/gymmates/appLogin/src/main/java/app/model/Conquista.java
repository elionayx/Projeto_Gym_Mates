package app.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Conquista {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    private TipoConquista tipo;

    private LocalDate data;

    @ManyToOne
    private Usuario usuario;

    public Conquista() {}
    public Conquista(TipoConquista tipo, LocalDate data, Usuario usuario) {
        this.tipo = tipo;
        this.data = data;
        this.usuario = usuario;
    }

    public TipoConquista getTipo() { return tipo; }
    public LocalDate getData() { return data; }
}

