package app.model;

public enum TipoConquista {
    TREINOS_5_SEMANA,
    TREINOS_10_MES
}

