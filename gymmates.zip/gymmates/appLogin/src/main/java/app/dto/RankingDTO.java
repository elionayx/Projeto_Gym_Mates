package app.dto;

import lombok.Data;

@Data

public class RankingDTO {
    private String nome;
    private Long pontos;

    public RankingDTO(String nome, Long pontos) {
        this.nome = nome;
        this.pontos = pontos;
    }

    public String getNome() {
        return nome;
    }

    public Long getPontos() {
        return pontos;
    }
}

